import json
def lambda_handler(event, context):
    session = event.get("sessionState", {}).get("sessionAttributes", {})
    fallback_count = int(session.get("fallbackCount", "0"))
    fallback_count += 1
    session["fallbackCount"] = str(fallback_count)

    if fallback_count < 3:
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "ElicitIntent"
                },
                "sessionAttributes": session
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "Sorry, I didn’t get that. How can I help you today?"
                }
            ]
        }
    else:
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close",
                    "fulfillmentState": "Failed"
                },
                "sessionAttributes": session
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "I'm having trouble understanding. Let me transfer you to someone who can help."
                }
            ]
        }
